// Fill out your copyright notice in the Description page of Project Settings.

#include "BaseObjectSpawner.h"
#include "DrawDebugHelpers.h"

// Sets default values
ABaseObjectSpawner::ABaseObjectSpawner()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	GEngine->GetFirstLocalPlayerController(GetWorld())->bEnableClickEvents = true;
	GEngine->GetFirstLocalPlayerController(GetWorld())->bShowMouseCursor = true;
	InputComponent->BindAction("ScreenClick", IE_Pressed, this, &ABaseObjectSpawner::SpawnObject);
}

// Called when the game starts or when spawned
void ABaseObjectSpawner::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ABaseObjectSpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

//FHitResult ABaseObjectSpawner::RaycastScreen() {
//	//Hit contains information about what the raycast hit.
//	FHitResult Hit;
//
//	//The length of the ray in units.
//	//For more flexibility you can expose a public variable in the editor
//	float RayLength = 200;
//
//	//The Origin of the raycast
//	FVector StartLocation = GEngine->GetFirstLocalPlayerController(GetWorld())->PlayerCameraManager->PCOwner->GetFocalLocation();
//
//	//The EndLocation of the raycast
//	FVector EndLocation = StartLocation + (GEngine->GetFirstLocalPlayerController(GetWorld())->PlayerCameraManager->PCOwner->GetControlRotation().Vector() * RayLength);
//
//	//Collision parameters. The following syntax means that we don't want the trace to be complex
//	FCollisionQueryParams CollisionParameters;
//
//	//Perform the line trace
////The ECollisionChannel parameter is used in order to determine what we are looking for when performing the raycast
//	ActorLineTraceSingle(Hit, StartLocation, EndLocation, ECollisionChannel::ECC_WorldDynamic, CollisionParameters);
//
//	//DrawDebugLine is used in order to see the raycast we performed
//	//The boolean parameter used here means that we want the lines to be persistent so we can see the actual raycast
//	//The last parameter is the width of the lines.
//	DrawDebugLine(GetWorld(), StartLocation, EndLocation, FColor::Green, true, -1, 0, 1.f);
//
//	GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, "Raycast Done");
//	UE_LOG(LogClass, Log, TEXT("RaycastDone"));
//
//	return Hit;
//}
//
//void ABaseObjectSpawner::SpawnObject()
//{
//	FHitResult hitInfo = RaycastScreen();
//
//	hitInfo.GetActor()->GetActorLocation();
//}

